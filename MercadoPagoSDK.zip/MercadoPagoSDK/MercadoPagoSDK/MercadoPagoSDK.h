//
//  MercadoPagoSDK.h
//  MercadoPagoSDK
//
//  Created by Matias Gualino on 6/4/15.
//  Copyright (c) 2015 MercadoPago. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MercadoPagoSDK.
FOUNDATION_EXPORT double MercadoPagoSDKVersionNumber;

//! Project version string for MercadoPagoSDK.
FOUNDATION_EXPORT const unsigned char MercadoPagoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MercadoPagoSDK/PublicHeader.h>


