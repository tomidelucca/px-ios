//
//  PaymentMethodRow.swift
//  MercadoPagoSDK
//
//  Created by Matias Gualino on 31/12/14.
//  Copyright (c) 2014 com.mercadopago. All rights reserved.
//

import Foundation

public class PaymentMethodRow : NSObject {
    public var label : String?
    public var card : Card?
    public var icon : String?
    
}